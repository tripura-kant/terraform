# automation_july_2023
Repo for batch 60 on automation in AWS using Terraform
