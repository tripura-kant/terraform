there are 3 files

main.tf contains all the terraform code
userdata.sh contains the userscript
variables.tf contains all variables used in terraform code